Any standard Tcl extensions can be placed here.  Tcl will search all
subdirectories for packages.  If you have extensions installed in
your system-wide Tcl installation (probably a better idea), then they
will of course be seen as well.  

Tcl (and therefore AlphaTcl) will usually use the newest version of a 
package it has available.

Most binaries here are for Windows.  If someone wishes to send me binaries
for MacOS X, Linux (or other standard *nix) I'd be happy to distribute
them.
